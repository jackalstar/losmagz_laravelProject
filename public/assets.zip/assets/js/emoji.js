$(".emojiPicker").emojioneArea({
    inline: true,
    placement: 'absleft',
    pickerPosition: "top left",
});